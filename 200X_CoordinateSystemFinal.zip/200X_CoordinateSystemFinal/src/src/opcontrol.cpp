#include "main.h"
#include "api.h"
#include "pros/rtos.h"
#include "functions.hpp"
#include "motorDefs.hpp"

void opcontrol() {

  RightF.set_brake_mode(MOTOR_BRAKE_HOLD);
  RightB.set_brake_mode(MOTOR_BRAKE_HOLD);
  LeftF.set_brake_mode(MOTOR_BRAKE_HOLD);
  LeftB.set_brake_mode(MOTOR_BRAKE_HOLD);
  Intake.set_brake_mode(MOTOR_BRAKE_HOLD);
  Puncher.set_brake_mode(MOTOR_BRAKE_COAST);
  Angler.set_brake_mode(MOTOR_BRAKE_HOLD);
  Lift.set_brake_mode(MOTOR_BRAKE_HOLD);

  Puncher.move_velocity(200);
  pros::delay(500);
  Puncher.move_velocity(0);

  Angler.move_absolute(0, 200);

  pros::Task Drive_task(Drive, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "");
  pros::Task punchTask(puncherTask, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "");


  while(true){
    printf("angle: %f\n", LeftF.get_position());

    pros::delay(20);
  }
}
