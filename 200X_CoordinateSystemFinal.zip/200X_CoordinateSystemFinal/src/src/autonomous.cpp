#include "main.h"
#include "functions.hpp"
#include "motorDefs.hpp"
/**
 * Runs the user autonomous code. This function will be started in its own task
 * with the default priority and stack size whenever the robot is enabled via
 * the Field Management System or the VEX Competition Switch in the autonomous
 * mode. Alternatively, this function may be called in initialize or opcontrol
 * for non-competition testing purposes.
 *
 * If the robot is disabled or communications is lost, the autonomous task
 * will be stopped. Re-enabling the robot will restart the task, not re-start it
 * from where it left off.
 */
void blueTopAuton(){

  //Our Middle Flag and Park
   xpos=5;
   ypos=3;
   theta1=0;
   move(xpos,ypos,5,4,theta1);
   punch();
   reverse(xpos,ypos,5,2);
   turns(xpos,ypos,0,2,theta1);
   gunIt(1500);
}
void blueBotAuton(){
  // xpos=5, ypos=1, theta1=270;
  // turns(xpos,ypos,2,6,theta1);
  // punch();
  // move(xpos,ypos,5,2,theta1);
  // turns(xpos,ypos,0,2,theta1);
  // gunIt(1500);
  xpos=5;
  ypos=1;
  theta1=270;
  Intake.move_velocity(100);
  liftUp(-400);
  move(xpos,ypos,2.6,1.2,theta1);
  pros::delay(100);
  Intake.move_velocity(0);
  reverse(xpos,ypos,4.5,1.2);
  turns(xpos,ypos,3.5,5.5,theta1);
  anglePunch(390);
  Puncher.move_absolute(0, 200);


  //Park
  turns(xpos,ypos,3.8,2.5,theta1);
  move(xpos,ypos,3.8,3.75,theta1);

  //Scrape and descore

  // move(xpos,ypos,4.5,0,theta1);
  // turns(xpos,ypos,3,0,theta1);
  // Lift.move_absolute(-800, 200);
  // move(xpos,ypos,2.8,0,theta1);
  // Lift.move_absolute(0, 200);
  // Intake.move_velocity(150);
  // Lift.move_absolute(-400, 200);
  // reverse(xpos,ypos,4,0);
  // Intake.move_velocity(0);
  // turns(xpos,ypos,0.75,5,theta1);
  // anglePunch(390);
}
void redBotAuton2(){
  xpos=0;
  ypos=1;
  theta1=0;
  punch();
  Puncher.move_velocity(0);
  pros::delay(500);
  Puncher.move_velocity(0);
  //
  liftUp(400);
  intakeStart();
  move(xpos,ypos,2.1,1, theta1);
  reverse(xpos,ypos,0.5,1);
  intakeStop();
  turns(xpos,ypos,2.5,6,theta1);
  punch();
  move(xpos,ypos,0.25,2.5,theta1);
  turns(xpos,ypos,4,2.5,theta1);
  gunIt(1900);
  motorsStop();
  Angler.move_absolute(0,200);
}
void blueBotAutonBasic(){
  xpos=5;
  ypos=1;
  theta1=0;
  punch();
  Puncher.move_velocity(200);
  pros::delay(500);
  Puncher.move_velocity(0);
  liftUp(400);
  intakeStart();
  move(xpos,ypos,2.8,1, theta1);
  reverse(xpos,ypos,4.5,1);
  intakeStop();
  turns(xpos,ypos,3.3,5,theta1);
  punch();
  move(xpos,ypos,5,2.55,theta1);
  turns(xpos,ypos,4,2.55,theta1);
  gunIt(2500);
  motorsStop();
  Angler.move_absolute(0,200);
}
void redTopAuton(){
  xpos=0; //Starting Xpos
  ypos=3; //Starting Ypos
  theta1=90;
  intakeStart();
  move(xpos,ypos,1.8,3, theta1);
  intakeStop();
  reverse(xpos,ypos,0,3);
  turns(xpos,ypos,0,5,theta1);
  //shoot left flags (double shot)
  turns(xpos,ypos,2,5,theta1);
  move(xpos,ypos,0.5,3.5,theta1);
  scrape(xpos, 1);
  //shoot middle flags
  motorsStop();
}
void redTopAutonBasic(){
  xpos=0;
  ypos=3;
  theta1=0;
  move(xpos,ypos,0,4,theta1);
  punch();
  reverse(xpos,ypos,0,1.9);
  turns(xpos,ypos,3,1.9,theta1);
  gunIt(1500);
}
void redBotAutonBasic(){
  xpos=0,ypos=1,theta1=0;
  move(xpos,ypos,0,2,theta1);
  punch();
  turns2(xpos,ypos,2,2,theta1);
  gunIt(1500);
}
void redBotAuton(){
  xpos=0;
  ypos=1;
  theta1=90;
  //Get Ball shoot middle flags
  // intakeStart();
  // move(xpos,ypos,1.8,1,theta1);
  // intakeStop();
  // reverse(xpos,ypos,1.5,1);
  // turns(xpos,ypos,2,5, theta1);
  // //Doubleshot
  // motorsStop();

  // 4 flags
  Intake.move_velocity(50);
  Lift.move_absolute(-800,200);
  move(xpos,ypos,2.2,1,theta1);
  Intake.move_velocity(0);
  reverse(xpos,ypos,1.5,1);
  Lift.move_absolute(-50,200);
  turns(xpos,ypos,2.3,5,theta1);
  AutonDoubleShot();
  move(xpos,ypos,1.5,-0.3,theta1);
  Lift.move_absolute(-800, 200);
  move(xpos,ypos,2,-0.3,theta1);
  Intake.move_velocity(200);
  Lift.move_absolute(0, 200);
  reverse(xpos,ypos,1.2,0);
  Intake.move_velocity(0);
  turns(xpos,ypos,4,5,theta1);
  //Shoot cross court maybe adjust values


}
void autonomous() {
  redBotAuton2();
}
