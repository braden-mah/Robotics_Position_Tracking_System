#include "main.h"
#include "functions.hpp"
#include "motorDefs.hpp"
#include <math.h>

double degreeConstant = 0.0118*1000;
double one_tile = 667;
double deltaT;
double target;
char turn;
double t2;
double xDistance, yDistance, distance, current, error, pwr, kP=0.15, kD=1.35, lastError, P, D;
double rAcute;
int quadrant;
bool skipT2;
double xpos, ypos, x2, y2, theta1;
void liftUp(double dist){
  Lift.move_absolute(-dist,200);
}
void gunIt(double stop){
  LeftB.move_velocity(200);
  RightF.move_velocity(200);
  RightB.move_velocity(200);
  LeftF.move_velocity(200);
  pros::delay(stop);
  LeftB.move_velocity(0);
  RightF.move_velocity(0);
  RightB.move_velocity(0);
  LeftF.move_velocity(0);

}
void liftDown(double pos){
  Lift.move_absolute(pos,200);
}
void anglePunch(double d){
  Puncher.tare_position();
  while(Puncher.get_position()<1800){
    Puncher.move_velocity(200);
  }
  Puncher.move_velocity(0);
  Intake.move_velocity(200);
  Angler.move_absolute(d,200);
  pros::delay(200);
  Puncher.tare_position();
  while(Puncher.get_position()<1800){
    Puncher.move_velocity(200);
  }
  Puncher.move_velocity(0);
  Intake.move_velocity(0);
}
void motorsStop(){
  LeftB.move_velocity(0);
  RightF.move_velocity(0);
  RightB.move_velocity(0);
  LeftF.move_velocity(0);
}
void intakeStart (){
  Intake.move_velocity(200);
}
void intakeStop(){
  Intake.move_velocity(0);
}

void turnRight(){
  LeftB.move_velocity(50);
  LeftF.move_velocity(50);
  RightF.move_velocity(-50);
  RightB.move_velocity(-50);
}

void turnLeft(){
  LeftB.move_velocity(-50);
  LeftF.move_velocity(-50);
  RightF.move_velocity(50);
  RightB.move_velocity(50);
}

void punch(){
  Puncher.tare_position();
  while(Puncher.get_position() < 2200){
    Puncher.move_velocity(200);
  }
  Puncher.move_velocity(0);
}
void getQuadrant(){
  if (xDistance>0 && yDistance>0) {
			quadrant=1; //x+ y+ therefore quadrant 1
		}
		else if (xDistance<0 && yDistance>0) {
			quadrant=4; //x- y+ therefore quadrant 2
		}
		if (xDistance<0 && yDistance<0) {
			quadrant=3; //x- y- therefore quadrant 3
		}
		else if (xDistance>0 && yDistance<0) {
			quadrant=2; //x+ y- therefore quadrant 4
		}
		if (xDistance==0||yDistance==0) {
			skipT2=true;
			if (xDistance==0 && yDistance>0) {
				t2=0; //x0 y+ therefore turning to 0 degrees
			}
			else if (xDistance==0 & yDistance<0) {
				t2=180; //x0 y- therefore turning to 180 degrees
			}
			else if (yDistance==0 && xDistance>0) {
				t2=90; //x+ y0 therefore turning to 90 degrees
			}
			else if (yDistance==0 && xDistance<0) {
				t2=270; //x- y0 therefore turning to 270 degrees
			}
		}
}
void findT2() {
		if (skipT2==false) {
      //Find the related acute angle with trigonometry (tan inverse of y distance and x distance)
			rAcute=(180/M_PI)*(abs(atan(yDistance/xDistance)));
      //Find the principal angle
      if (quadrant==1) {
				t2=90-rAcute; //principle angle from quadrant 1
			}
			else if (quadrant==4) {
				t2=270+rAcute; //principle angle from quadrant 2
			}
			else if (quadrant==3) {
				t2=270-rAcute; //principle angle from quadrant 3
			}
			else if (quadrant==2) {
				t2=90+rAcute; //principle angle from quadrant 4
			}
		}
		else if (skipT2==true) {
			skipT2=false;
		}
	}
void orient(double t1) {
	deltaT=t2-t1; //change from angle 1 to angle 2
	if (deltaT<0) { //t2 is smaller than t1, so assume turning left
		deltaT=abs(deltaT);
		if (deltaT>=180) {
			deltaT=360-deltaT; //turning left is less efficient, so turn right
			turn='r';
		}
		else { //turning left is more efficient, so turn left
			turn='l';
		}
	}
	else{  //t2 is greater than t1, so assume turning right
	      if (deltaT>=180){ //turning right is less efficient, so turn left
	          deltaT=360-deltaT;
	          turn='l';
	      }
	      else{ //turning right is more efficient, so turn right
	        turn='r';
	      }
	    }
	}
void reverse(double x1, double y1, double x2, double y2){
  xDistance=x2-x1;
  yDistance=y2-y1;
  // Use pythagorean's theorem to find total distance to travel based on x and y components
  distance=sqrt(pow(xDistance,2)+pow(yDistance,2));
  // Use motors to move forward
  target=-800*2*(1/1.75)*distance;
  LeftF.tare_position();
  do{
    current=LeftF.get_position();
    error=target-current;
    pwr=abs(error*kP);
    LeftF.move_velocity(-pwr);
    RightF.move_velocity(-pwr);
    LeftB.move_velocity(-pwr);
    RightB.move_velocity(-pwr);
  }
  while (!(error<=20 && error>=-20));
  LeftF.move_velocity(0);
  LeftB.move_velocity(0);
  RightF.move_velocity(0);
  RightB.move_velocity(0);
  xpos=x2;
  ypos=y2;
}
void turns2(double x1, double y1, double x2, double y2, double t1){
  xDistance=x2-x1;
  yDistance=y2-y1;
  getQuadrant();
  findT2();
  orient(t1);
  double kP=0.15;
  double kD=1.35;
  double current, error, pwr, P, D, lastError;
  target=deltaT*9.233333333333333333333;
  do{
    current=LeftF.get_position();
    error=(target-current);
    lastError=error;

    P=error*kP;
    D=(error-lastError)*kD;

    pwr=P + D;

    if (turn=='l'){
      LeftF.move_velocity(-pwr);
      LeftB.move_velocity(-pwr);
      RightF.move_velocity(pwr);
      RightB.move_velocity(pwr);
    }
    else if (turn=='r'){
      LeftF.move_velocity(pwr);
      LeftB.move_velocity(pwr);
      RightF.move_velocity(-pwr);
      RightB.move_velocity(-pwr);
    }
  }
  while (!(error<=5 && error>=-5));
  LeftF.move_velocity(0);
  LeftB.move_velocity(0);
  RightF.move_velocity(0);
  RightB.move_velocity(0);
}
void turns(double x1, double y1, double x2, double y2, double t1){
  xDistance=x2-x1;
  yDistance=y2-y1;
  getQuadrant();
  findT2();
  orient(t1);
  //Turning left
  target=5.4333333333*2*1.2*6/8.1*2*deltaT;
  if (turn=='l'){
    turnLeft();
    pros::delay(degreeConstant*deltaT);
    motorsStop();
  }
  //Turning right
  else if (turn=='r'){
    turnRight();
    pros::delay(degreeConstant*deltaT);
    motorsStop();
  }
  theta1=t2;
}
void move(double x1, double y1, double x2, double y2, double t1){
  xDistance=x2-x1;
  yDistance=y2-y1;
  getQuadrant();
  findT2();
  orient(t1);
  //Turning left
  target=5.4333333333*2*1.2*6/8.1*2*deltaT;
  if (turn=='l'){
    turnLeft();
    pros::delay(degreeConstant*deltaT);
    motorsStop();
  }
  //Turning right
  else if (turn=='r'){
    turnRight();
    pros::delay(degreeConstant*deltaT);
    motorsStop();
  }

  xDistance=abs(xDistance);
  yDistance=abs(yDistance);
  // Use pythagorean's theorem to find total distance to travel based on x and y components
  distance=sqrt(pow(xDistance,2)+pow(yDistance,2));
  // Use motors to move forward
  target=800*2*(1/1.75)*distance;
  LeftF.tare_position();
  do{
    current=LeftF.get_position();
    error=target-current;
    pwr=abs(error*kP);
    LeftF.move_velocity(pwr);
    RightF.move_velocity(pwr);
    LeftB.move_velocity(pwr);
    RightB.move_velocity(pwr);
  }
  while (!(error<=20 && error>=-20));
  LeftF.move_velocity(0);
  LeftB.move_velocity(0);
  RightF.move_velocity(0);
  RightB.move_velocity(0);
  xpos=x2;
  ypos=y2;
  theta1=t2;
}

using namespace pros;//just so i dont have to do pros:: before everything
int AutoCount = 0;
void anglePID(double target){
  // pros::Motor Angler(15);
  Angler.set_brake_mode(MOTOR_BRAKE_HOLD);
  // pros::ADIPotentiometer anglePot(2);

  double current;
  double kP = 3;
  double kI = 0.0000003;
  double kD = 1.35;
  double error;
  double totalError;
  double lastError;
  double pwr;

  do{
    current = AnglePot.get_value();
    error = target - current;

    totalError += error;
    lastError = error;

    double P = kP * error;
    double I = kI * totalError;
    double D = kD * (error - lastError);

    pwr = P+I+D;
    Angler.move_velocity(pwr);

  }while(!(error<= 2 && error>= -2));

  Angler.move_velocity(0);

}

void Shoot(void*){
  while(true){
    if(master.get_digital(DIGITAL_A)){
      Puncher.tare_position();
      while(Puncher.get_position() < 2000){
        Puncher.move_velocity(200);
      }
      Puncher.move_velocity(0);
    }

    if(master.get_digital(DIGITAL_X)){
      Puncher.tare_position();
      while(Puncher.get_position() < 2000){
        Puncher.move_velocity(200);
      }
      Puncher.move_velocity(0);
    }

    if(master.get_digital(DIGITAL_Y)){
      Puncher.tare_position();
      while(Puncher.get_position() < 2000){
        Puncher.move_velocity(200);
      }
      Puncher.move_velocity(0);
    }

    if(master.get_digital(DIGITAL_UP)){
      Puncher.tare_position();
      while(Puncher.get_position() < 2000){
        Puncher.move_velocity(200);
      }
      Puncher.move_velocity(0);
    }

    if(master.get_digital(DIGITAL_DOWN)){
      Puncher.tare_position();
      while(Puncher.get_position() < 2000){
        Puncher.move_velocity(200);
      }
      Puncher.move_velocity(0);
    }

    if(master.get_analog(ANALOG_RIGHT_Y) > 40){
      Puncher.move_velocity(200);
    }
    else{
      Puncher.move_velocity(0);
    }
  }
}

void IntakeRoll(void*){
  while(true){
    if(master.get_digital(DIGITAL_X)){
      while(Puncher.get_position() < 1800){
        pros::delay(1);
      }

      Intake.tare_position();
      while(Intake.get_position() < 2000){
        Intake.move_velocity(200);
      }
      Intake.move_velocity(0);

    }

    if(master.get_digital(DIGITAL_Y)){
      while(Puncher.get_position() < 1800){
        pros::delay(1);
      }

      Intake.tare_position();
      while(Intake.get_position() < 2000){
        Intake.move_velocity(200);
      }
      Intake.move_velocity(0);
    }

    if(master.get_digital(DIGITAL_UP)){
      while(Puncher.get_position() < 1800){
        pros::delay(1);
      }

      Intake.tare_position();
      while(Intake.get_position() < 2000){
        Intake.move_velocity(200);
      }
      Intake.move_velocity(0);
    }

    if(master.get_digital(DIGITAL_DOWN)){
      while(Puncher.get_position() < 1800){
        pros::delay(1);
      }

      Intake.tare_position();
      while(Intake.get_position() < 2000){
        Intake.move_velocity(200);
      }
      Intake.move_velocity(0);
    }
  }
}

void puncherTask(void*){//function to reset puncher
  pros::Task shootTask(Shoot, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "");

  while(true){
    if(master.get_digital(DIGITAL_A)){
      while(Puncher.get_position() < 1800){
        pros::delay(1);
      }
      Puncher.tare_position();
      Angler.move_absolute(400, 200);

      Puncher.tare_position();
      while(Puncher.get_position() < 2000){pros::delay(1);}
      Angler.move_absolute(0, 200);
    }

    if(master.get_digital(DIGITAL_Y)){
      Angler.move_absolute(400, 200);
      pros::delay(300);
      Angler.move_velocity(0);
      while(Puncher.get_position() < 2000){pros::delay(1);}
      Angler.move_absolute(0, 200);
    }

    if(master.get_digital(DIGITAL_UP) ){
      Angler.move_absolute(500, 200);
      while(Puncher.get_position() < 2000){pros::delay(1);}
      Angler.move_absolute(0, 200);
    }

    if(master.get_digital(DIGITAL_DOWN)){
      Angler.move_absolute(200, 200);
      while(Puncher.get_position() < 2300)
      {
        pros::delay(1);
      }
      Angler.move_absolute(0, 200);
    }
    pros::delay(20);
  }
}


extern const lv_img_t six_logo;
extern const lv_img_t lance;
extern int AutoCount;

static lv_res_t btn_click_action(lv_obj_t * btn1){
  uint8_t id = lv_obj_get_free_num(btn1);

  if(id == 1){
    AutoCount = 1;
    printf("Mode %d: Red Back\n", AutoCount);
  }

  if(id == 2){
    AutoCount = 2;
    printf("Mode %d: Red Front\n", AutoCount);
  }

  if(id == 3){

    AutoCount = 3;
    printf("Mode %d: Blue Back\n", AutoCount);
  }

  if(id == 4){
    AutoCount = 4;
    printf("Mode %d: Blue Front\n", AutoCount);
  }

  if(id == 5){
    AutoCount = 5;
    printf("Mode %d: Skills\n", AutoCount);
  }

  return LV_RES_OK; /*Return OK if the button is not deleted*/
}

void Gui(){
  lv_theme_t * th = lv_theme_alien_init(100, NULL);

  lv_obj_t *tabview;
  tabview = lv_tabview_create(lv_scr_act(), NULL);

  lv_obj_t *RedAutoSelect = lv_tabview_add_tab(tabview, "Red");//RedAutoSelect
  lv_obj_t *BlueAutoSelect = lv_tabview_add_tab(tabview, "Blue");//BlueAutoSelect
  lv_obj_t *ShotTuner= lv_tabview_add_tab(tabview, "ShotTuner");//RPM selector

  lv_obj_t * label = lv_label_create(RedAutoSelect, NULL);
  lv_label_set_text(label, "Red Auto Selector\nClick the Button to switch Auto");

  lv_obj_t * label2 = lv_label_create(BlueAutoSelect, NULL);
  lv_label_set_text(label2, "Blue Auto Selector\nClick the button to switch Auto");

  lv_obj_t * btn1 = lv_btn_create(RedAutoSelect, NULL);
  lv_cont_set_fit(btn1, true, true); /*Enable resizing horizontally and vertically*/
  lv_obj_align(btn1, label, LV_ALIGN_OUT_BOTTOM_LEFT, 0, 35);
  lv_obj_set_free_num(btn1, 1);   /*Set a unique number for the button*/
  lv_btn_set_action(btn1, LV_BTN_ACTION_CLICK, btn_click_action);

  /*Add a label to the button*/
  label = lv_label_create(btn1, NULL);
  lv_label_set_text(label, "Back");

  /*Button two*/

  lv_obj_t * btn2 = lv_btn_create(RedAutoSelect, NULL);
  lv_cont_set_fit(btn2, true, true); /*Enable resizing horizontally and vertically*/
  lv_obj_align(btn2, label, LV_ALIGN_OUT_BOTTOM_RIGHT, 390, -48);
  lv_obj_set_free_num(btn2, 2);/*Set a unique number for the button*/
  lv_btn_set_action(btn2, LV_BTN_ACTION_CLICK, btn_click_action);

  /*Add a label to the button*/
  label = lv_label_create(btn2, NULL);
  lv_label_set_text(label, "Front");

  /*Button Three*/

  lv_obj_t * btn3 = lv_btn_create(BlueAutoSelect, NULL);
  lv_cont_set_fit(btn3, true, true); /*Enable resizing horizontally and vertically*/
  lv_obj_align(btn3, label, LV_ALIGN_OUT_BOTTOM_LEFT, 80, -40);
  lv_obj_set_free_num(btn3, 3);   /*Set a unique number for the button*/
  lv_btn_set_action(btn3, LV_BTN_ACTION_CLICK, btn_click_action);

  /*Add a label to the button*/
  label = lv_label_create(btn3, NULL);
  lv_label_set_text(label, "Back");

  /*Button four*/
  lv_obj_t * btn4 = lv_btn_create(BlueAutoSelect, NULL);
  lv_cont_set_fit(btn4, true, true); /*Enable resizing horizontally and vertically*/
  lv_obj_align(btn4, label, LV_ALIGN_OUT_BOTTOM_RIGHT, 400, -50);
  lv_obj_set_free_num(btn4, 4);/*Set a unique number for the button*/
  lv_btn_set_action(btn4, LV_BTN_ACTION_CLICK, btn_click_action);

  /*Add a label to the button*/
  label = lv_label_create(btn4, NULL);
  lv_label_set_text(label, "Front");

  lv_obj_t * sixLogo = lv_img_create(lv_scr_act(), NULL);
  lv_img_set_src(sixLogo, &six_logo);
  lv_obj_align(sixLogo, NULL, LV_ALIGN_IN_TOP_RIGHT, 30, 60);

  lv_obj_t * LanceLogo = lv_img_create(lv_scr_act(), NULL);
  lv_img_set_src(LanceLogo, &lance);
  lv_obj_align(LanceLogo, NULL, LV_ALIGN_IN_TOP_RIGHT, -120, 190);

}

void liftTask(void*){
  while(true){
    if(master.get_digital(DIGITAL_R1)){
      Lift.move_velocity(200);
    }

    else if(master.get_digital(DIGITAL_R2)){
      Lift.move_velocity(-200);
    }

    else{
      Lift.move_velocity(0);
    }
    pros::delay(20);
  }
}

void Drive(void*){
  pros::Task lftTask(liftTask, (void*)"PROS", TASK_PRIORITY_DEFAULT, TASK_STACK_DEPTH_DEFAULT, "");
  RightF.set_brake_mode(MOTOR_BRAKE_HOLD);
  RightB.set_brake_mode(MOTOR_BRAKE_HOLD);
  LeftF.set_brake_mode(MOTOR_BRAKE_HOLD);
  LeftB.set_brake_mode(MOTOR_BRAKE_HOLD);
  Puncher.set_encoder_units(MOTOR_ENCODER_COUNTS);

  while(true){

    if(master.get_analog(ANALOG_LEFT_Y) == 0 && master.get_analog(ANALOG_LEFT_X) == 0 && master.get_analog(ANALOG_RIGHT_X) == 0){
      LeftF.move_velocity(0);
      LeftB.move_velocity(0);
      RightB.move_velocity(0);
      RightF.move_velocity(0);
    }
    else {//drive code
      LeftF.move(master.get_analog(ANALOG_LEFT_Y) + master.get_analog(ANALOG_RIGHT_X) + master.get_analog(ANALOG_LEFT_X));
      LeftB.move(master.get_analog(ANALOG_LEFT_Y) + master.get_analog(ANALOG_RIGHT_X) - master.get_analog(ANALOG_LEFT_X));
      RightF.move(master.get_analog(ANALOG_LEFT_Y) - master.get_analog(ANALOG_RIGHT_X) - master.get_analog(ANALOG_LEFT_X));
      RightB.move(master.get_analog(ANALOG_LEFT_Y) - master.get_analog(ANALOG_RIGHT_X) + master.get_analog(ANALOG_LEFT_X));
    }

    if(master.get_digital(DIGITAL_L1)){
      Intake.move_velocity(-200);
    }

    else if(master.get_digital(DIGITAL_L2)){
      Intake.move_velocity(200);
    }
    else{
      Intake.move_velocity(0);
    }


    delay(20);
  }
}

  void AutonDoubleShot(){
    while(Puncher.get_position() < 2000){
      Puncher.move_velocity(200);
    }
    Puncher.move_velocity(0);

    Intake.move_velocity(200);

    Angler.move_absolute(400, 200);

    pros::delay(300);

    Puncher.tare_position();
    while(Puncher.get_position() < 2000){
      Puncher.move_velocity(200);
    }
    Puncher.move_velocity(0);
    Angler.move_absolute(0, 200);
  }
